module.exports = {
  development: {
    server: {},
    client: {},
  },

  production: {
    server: {},
    client: {},
  },
};
