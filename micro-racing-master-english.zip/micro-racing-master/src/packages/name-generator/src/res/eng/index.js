export {default as animals} from './animals.json';
export {default as adjectives} from './adjectives.json';
