import * as engLang from './eng';

export default {
  eng: engLang,
};
