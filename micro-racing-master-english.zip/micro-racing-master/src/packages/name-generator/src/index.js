export {default} from './generateName';
