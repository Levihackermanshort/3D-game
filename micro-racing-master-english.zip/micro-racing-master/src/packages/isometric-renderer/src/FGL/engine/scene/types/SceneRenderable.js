export default class SceneRenderable {
  /* eslint-disable class-methods-use-this, no-unused-vars */
  update(interpolation) {}

  render(interpolate, mpMatrix) {}
  /** eslint-enable class-methods-use-this, no-unused-vars */
}
