export {default as plainTerrainWireframe} from './createPlainTerrainWireframe';
export {default as triangle} from './createTriangle';
export {default as box} from './createBox';
export {default as pyramid} from './createPyramid';
export {default as tileTerrain} from './createTileTerrain';
