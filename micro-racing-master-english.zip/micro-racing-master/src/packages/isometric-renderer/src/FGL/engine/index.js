import * as meshes from './meshes';
import * as materials from './materials';

export {
  meshes,
  materials,
};
