import createMatrixOptimizedOperations from '../createMatrixOptimizedOperations';

export default createMatrixOptimizedOperations(
  {
    w: 4,
    vector: 3,
  },
);
