import createVectorOptimizedOperations from '../createVectorOptimizedOperations';

export default createVectorOptimizedOperations(4);
