const vectorAngle = vec => Math.atan2(vec[1], vec[0]);

export default vectorAngle;
