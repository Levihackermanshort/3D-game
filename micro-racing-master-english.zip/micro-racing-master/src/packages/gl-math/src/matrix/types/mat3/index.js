import createMatrixOptimizedOperations from '../createMatrixOptimizedOperations';

export default createMatrixOptimizedOperations(
  {
    w: 3,
    vector: 3,
  },
);
