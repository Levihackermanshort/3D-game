const createSquare = w => ({
  w,
  h: w,
});

export default createSquare;
