const lerp = (a, b, value) => a + (b - a) * value;

export default lerp;
