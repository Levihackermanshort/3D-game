const RATIO = 180 / Math.PI;

export default num => num * RATIO;
