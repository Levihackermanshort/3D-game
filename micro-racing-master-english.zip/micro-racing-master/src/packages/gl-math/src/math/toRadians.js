const RATIO = Math.PI / 180;

export default num => num * RATIO;
