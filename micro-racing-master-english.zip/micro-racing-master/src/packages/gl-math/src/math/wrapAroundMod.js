const wrapAroundMod = (num, length) => (num + length) % length;

export default wrapAroundMod;
