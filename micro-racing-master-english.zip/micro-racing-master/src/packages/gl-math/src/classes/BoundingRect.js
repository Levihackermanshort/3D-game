export default class BoundingRect {
  constructor(pos, size) {
    this.pos = pos;
    this.size = size;
  }
}
