export {default as useInputs} from './useInputs'; // eslint-disable-line import/prefer-default-export
