import getIndexBy from './getIndexBy';

export default getIndexBy('name');
