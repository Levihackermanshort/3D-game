const alwaysThrow = (obj) => {
  throw new Error(obj);
};

export default alwaysThrow;
