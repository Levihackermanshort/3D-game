const isEmptyObject = obj => Object.keys(obj).length === 0;

export default isEmptyObject;
