export const MAGIC_HYDRATED_STORE_ID_ATTRIB = 'hydrated-css';

export const MAGIC_SSR_STORE_ID_ATTRIB = 'ssr-css';

export const HYDRATION_CACHE_VARIABLE = '__injected_classes';
