import createHydratedSheetStore from './createHydratedSheetStore';

export default createHydratedSheetStore(
  {
    id: 'x',
  },
);
