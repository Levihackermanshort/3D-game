export {default} from './GameCanvas';
