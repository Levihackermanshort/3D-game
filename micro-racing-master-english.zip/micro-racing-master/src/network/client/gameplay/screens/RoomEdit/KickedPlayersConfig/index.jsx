export {default} from './KickedPlayersConfig';
