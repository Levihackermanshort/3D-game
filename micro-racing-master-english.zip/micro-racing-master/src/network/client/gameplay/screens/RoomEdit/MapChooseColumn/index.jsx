export {default} from './MapChooseColumn';
