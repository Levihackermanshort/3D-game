export {default} from './PlayersListConfig';
