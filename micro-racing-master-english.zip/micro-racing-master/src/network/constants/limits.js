/**
 * Maximum inputs count that can be predicted by player,
 * if server not respond after 10 inputs in queue something
 * wrong happened
 */

export const MAX_INPUTS_QUEUE_LENGTH = 80;

export const SERVER_STACK_INPUTS = 10;
