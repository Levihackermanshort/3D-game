export const SERVER_PORT = process.env.PORT || process.env.APP_PORT || 3000;

export const SERVER_PROD = process.env.NODE_ENV === 'production';
