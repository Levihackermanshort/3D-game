export default [
  '#ff0044',
  '#63c74d',
  '#0099db',
];
