import * as LANG from './pack';

// eslint-disable-next-line import/prefer-default-export
export const GAME_LANG_PACK = LANG;
