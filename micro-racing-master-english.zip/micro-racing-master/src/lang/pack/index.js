export {default as en} from './en';
export {default as pl} from './pl';
